﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ASPCore_Final.Models
{
    public class Thongtinhoadon
    {
        public string HoTen_NgNhan { get; set; }
        public string Dia_Chi { get; set; }
        public string Ghi_Chu { get; set; }
        public string Sdt { get; set; }
    }
}
