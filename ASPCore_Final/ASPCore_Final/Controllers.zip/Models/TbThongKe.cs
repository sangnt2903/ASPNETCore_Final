﻿using System;
using System.Collections.Generic;

namespace ASPCore_Final.Models
{
    public partial class TbThongKe
    {
        public int MaTb { get; set; }
        public DateTime ThoiGian { get; set; }
        public long SoTruyCap { get; set; }
    }
}
